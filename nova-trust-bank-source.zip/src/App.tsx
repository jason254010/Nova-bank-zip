import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Toast } from './components/common/Toast';
import { Header } from './components/common/Header';
import { AppLayout } from './components/common/AppLayout';
import { SupportWidget } from './components/common/SupportWidget';
import { OwnerSetup } from './components/auth/OwnerSetup';
import { OwnerLogin } from './components/auth/OwnerLogin';
import { CustomerLogin } from './components/auth/CustomerLogin';
import { OwnerDashboard } from './components/owner/OwnerDashboard';
import { CustomerDashboard } from './components/customer/CustomerDashboard';
import { Headphones, Building2, Download } from 'lucide-react';

const getInitialRoute = (): 'OWNER' | 'CUSTOMER' => {
  const path = window.location.pathname.toLowerCase();
  if (path.includes('/admin')) {
    return 'OWNER';
  }
  return 'CUSTOMER';
};

const AppContent: React.FC = () => {
  const { user, hasOwner, isLoading } = useAuth();
  const [loginView, setLoginView] = useState<'OWNER' | 'CUSTOMER'>(getInitialRoute);
  const [customerActiveTab, setCustomerActiveTab] = useState('summary');
  const [ownerActiveTab, setOwnerActiveTab] = useState('home');
  const [isSupportOpen, setIsSupportOpen] = useState(false);

  // Sync URL and loginView with browser history & location
  useEffect(() => {
    const handlePopState = () => {
      const path = window.location.pathname.toLowerCase();
      if (path.includes('/admin')) {
        setLoginView('OWNER');
      } else {
        setLoginView('CUSTOMER');
      }
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const navigateToAdmin = () => {
    if (window.location.pathname !== '/admin') {
      window.history.pushState({}, '', '/admin');
    }
    setLoginView('OWNER');
  };

  const navigateToCustomer = () => {
    if (window.location.pathname !== '/login') {
      window.history.pushState({}, '', '/login');
    }
    setLoginView('CUSTOMER');
  };

  // Ensure path is consistent when user logs in or switches
  useEffect(() => {
    if (user) {
      if (user.role === 'OWNER') {
        if (window.location.pathname !== '/admin') {
          window.history.replaceState({}, '', '/admin');
        }
      } else if (user.role === 'CUSTOMER') {
        if (window.location.pathname !== '/login') {
          window.history.replaceState({}, '', '/login');
        }
      }
    }
  }, [user]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#F3F5F7] flex flex-col items-center justify-center p-6 text-center">
        <div className="w-12 h-12 bg-[#0057B8] rounded-2xl flex items-center justify-center text-white shadow-lg animate-pulse mb-3">
          <Building2 className="w-7 h-7" />
        </div>
        <h2 className="text-lg font-bold text-[#0F3557]">NOVA TRUST BANK</h2>
        <p className="text-xs text-[#6E7A87] mt-1 font-mono">Loading secure banking session...</p>
      </div>
    );
  }

  // Phase 1: On first launch, if no Owner exists, display Owner Setup page
  if (!hasOwner) {
    return <OwnerSetup />;
  }

  return (
    <div className="min-h-screen bg-[#F3F5F7] flex flex-col font-sans text-[#1E2A36]">
      {/* Temporary Project Source ZIP Download Banner */}
      <div className="bg-[#0057B8] text-white px-4 py-2.5 shadow-md flex items-center justify-between text-xs sm:text-sm font-medium border-b border-white/20 z-50">
        <div className="flex items-center gap-2">
          <Download className="w-4 h-4 text-[#A9D8F7] animate-bounce shrink-0" />
          <span className="truncate">Project Source Code ZIP is ready!</span>
        </div>
        <a
          href="/api/download-project-zip"
          download="nova-trust-bank-source.zip"
          className="bg-[#0F3557] hover:bg-[#08223a] text-white px-3 py-1.5 rounded-md font-bold text-xs flex items-center gap-1.5 transition-colors shadow-sm shrink-0"
        >
          <Download className="w-3.5 h-3.5 text-[#A9D8F7]" />
          <span>Download .ZIP</span>
        </a>
      </div>

      {!user ? (
        <>
          <Header onOpenSupport={() => setIsSupportOpen(true)} />
          <div className="flex-1 flex items-center justify-center">
            {loginView === 'OWNER' ? (
              <OwnerLogin onSwitchToCustomer={navigateToCustomer} />
            ) : (
              <CustomerLogin onSwitchToOwner={navigateToAdmin} />
            )}
          </div>
        </>
      ) : (
        <AppLayout
          activeTab={user.role === 'OWNER' ? ownerActiveTab : customerActiveTab}
          setActiveTab={user.role === 'OWNER' ? setOwnerActiveTab : setCustomerActiveTab}
          onOpenSupport={() => setIsSupportOpen(true)}
        >
          {user.role === 'OWNER' ? (
            <OwnerDashboard
              activeTab={ownerActiveTab}
              setActiveTab={setOwnerActiveTab}
              onOpenSupport={() => setIsSupportOpen(true)}
            />
          ) : (
            <CustomerDashboard
              onOpenSupport={() => setIsSupportOpen(true)}
              activeTab={customerActiveTab}
              setActiveTab={setCustomerActiveTab}
            />
          )}
        </AppLayout>
      )}

      {/* Floating Customer Service Button present on every page */}
      <div className="fixed bottom-6 right-6 z-40">
        <button
          onClick={() => setIsSupportOpen(!isSupportOpen)}
          className="bg-[#0057B8] hover:bg-[#004bb0] text-white p-3.5 rounded-full shadow-2xl flex items-center gap-2 text-xs font-semibold transition-transform hover:scale-105 active:scale-95 group border-2 border-white"
          title="Customer Service Chat"
        >
          <Headphones className="w-5 h-5" />
          <span className="hidden md:inline pr-1">Customer Support</span>
        </button>
      </div>

      {/* Real-time Customer Support Drawer */}
      <SupportWidget isOpen={isSupportOpen} onClose={() => setIsSupportOpen(false)} />

      <Toast />
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
