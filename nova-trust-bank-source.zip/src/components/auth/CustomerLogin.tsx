import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { apiRequest } from '../../services/api';
import { Building2, UserCheck, Lock, ArrowRight, ShieldCheck, KeyRound, Info } from 'lucide-react';

interface CustomerLoginProps {
  onSwitchToOwner: () => void;
}

export const CustomerLogin: React.FC<CustomerLoginProps> = ({ onSwitchToOwner }) => {
  const { login, showToast } = useAuth();
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Forgot password flow states
  const [showForgotModal, setShowForgotModal] = useState(false);
  const [resetEmail, setResetEmail] = useState('');
  const [otpCode, setOtpCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [otpHint, setOtpHint] = useState<string | null>(null);
  const [step, setStep] = useState<'REQUEST' | 'VERIFY'>('REQUEST');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!identifier || !password) {
      showToast('Please enter your account identifier and password.', 'error');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await apiRequest('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({
          loginIdentifier: identifier,
          password,
          loginType: 'CUSTOMER'
        })
      });

      login(res);
    } catch (err: any) {
      showToast(err.message || 'Customer authentication failed.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleRequestOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!resetEmail) return;

    try {
      const res = await apiRequest('/api/auth/forgot-password', {
        method: 'POST',
        body: JSON.stringify({ email: resetEmail })
      });
      showToast(res.message, 'success');
      if (res.otpCodeHint) {
        setOtpHint(res.otpCodeHint);
      }
      setStep('VERIFY');
    } catch (err: any) {
      showToast(err.message || 'Failed to generate reset OTP', 'error');
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!otpCode || !newPassword) return;

    try {
      const res = await apiRequest('/api/auth/reset-password', {
        method: 'POST',
        body: JSON.stringify({
          email: resetEmail,
          otpCode,
          newPassword
        })
      });

      showToast(res.message, 'success');
      setShowForgotModal(false);
      setStep('REQUEST');
      setOtpHint(null);
    } catch (err: any) {
      showToast(err.message || 'Failed to reset password', 'error');
    }
  };

  return (
    <div className="min-h-screen bg-[#F3F5F7] flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
        <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-[#0057B8] text-white shadow-lg mb-3">
          <Building2 className="w-8 h-8" />
        </div>
        <h2 className="text-2xl font-bold text-[#0F3557] font-sans">
          Nova Trust Banking
        </h2>
        <div className="mt-1 flex items-center justify-center gap-1.5">
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-[#0057B8] text-white">
            https://novatrustbank.web.app/login
          </span>
        </div>
        <p className="mt-1.5 text-xs text-[#6E7A87]">
          Secure Personal & Business Online Banking Access
        </p>
      </div>

      <div className="mt-6 sm:mx-auto sm:w-full sm:max-w-md px-4">
        <div className="bg-white py-8 px-6 sm:px-10 shadow-xl rounded-2xl border border-[#D9DEE5]">
          
          <div className="mb-5 p-3 bg-[#A9D8F7]/20 border border-[#A9D8F7] rounded-xl flex items-start gap-2.5">
            <Info className="w-4 h-4 text-[#0057B8] flex-shrink-0 mt-0.5" />
            <p className="text-[11px] text-[#0F3557] leading-relaxed">
              Customer accounts are provisioned directly by bank administration. Use your Email, 10-Digit Account Number, or Username to sign in.
            </p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-[#1E2A36] uppercase tracking-wider mb-1.5">
                Email / Account # / Username
              </label>
              <div className="relative rounded-lg shadow-xs">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#6E7A87]">
                  <UserCheck className="h-4 w-4" />
                </div>
                <input
                  type="text"
                  required
                  value={identifier}
                  onChange={e => setIdentifier(e.target.value)}
                  placeholder="e.g. 1092837465 or client@example.com"
                  className="block w-full pl-10 pr-3 py-2.5 text-xs rounded-lg border border-[#D9DEE5] focus:ring-2 focus:ring-[#0057B8] focus:border-[#0057B8] text-[#1E2A36]"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-semibold text-[#1E2A36] uppercase tracking-wider">
                  Password
                </label>
                <button
                  type="button"
                  onClick={() => setShowForgotModal(true)}
                  className="text-xs text-[#0057B8] hover:underline font-medium"
                >
                  Forgot Password?
                </button>
              </div>
              <div className="relative rounded-lg shadow-xs">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#6E7A87]">
                  <Lock className="h-4 w-4" />
                </div>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="block w-full pl-10 pr-3 py-2.5 text-xs rounded-lg border border-[#D9DEE5] focus:ring-2 focus:ring-[#0057B8] focus:border-[#0057B8] text-[#1E2A36]"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full flex justify-center items-center gap-2 py-3 px-4 rounded-xl text-xs font-semibold text-white bg-[#0057B8] hover:bg-[#004bb0] focus:outline-none focus:ring-2 focus:ring-[#0057B8] transition-colors shadow-md disabled:bg-[#D9DEE5]"
            >
              <span>{isSubmitting ? 'Verifying Account...' : 'Sign In to Banking Portal'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          <div className="mt-6 pt-6 border-t border-[#D9DEE5] text-center">
            <button
              onClick={onSwitchToOwner}
              className="text-xs font-medium text-[#0F3557] hover:text-[#0057B8] flex items-center justify-center gap-1.5 mx-auto"
            >
              <span>Bank Owner or Administrator? Switch to Admin Console</span>
              <ArrowRight className="w-3.5 h-3.5 text-[#0057B8]" />
            </button>
          </div>

        </div>
      </div>

      {/* Forgot / Reset Password Modal */}
      {showForgotModal && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-[#D9DEE5]">
            <h3 className="text-base font-bold text-[#0F3557] mb-1">Reset Password</h3>
            <p className="text-xs text-[#6E7A87] mb-4">
              {step === 'REQUEST'
                ? 'Enter your registered email address to receive an OTP code.'
                : 'Enter the 6-digit OTP sent to your email and your new password.'}
            </p>

            {step === 'REQUEST' ? (
              <form onSubmit={handleRequestOtp} className="space-y-4">
                <input
                  type="email"
                  required
                  value={resetEmail}
                  onChange={e => setResetEmail(e.target.value)}
                  placeholder="Registered Email Address"
                  className="w-full px-3 py-2 text-xs border border-[#D9DEE5] rounded-lg focus:outline-none focus:border-[#0057B8]"
                />

                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowForgotModal(false)}
                    className="px-4 py-2 text-xs font-medium text-[#6E7A87] hover:bg-[#F3F5F7] rounded-lg"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 text-xs font-semibold text-white bg-[#0057B8] hover:bg-[#004bb0] rounded-lg"
                  >
                    Send OTP
                  </button>
                </div>
              </form>
            ) : (
              <form onSubmit={handleResetPassword} className="space-y-3">
                {otpHint && (
                  <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-xs text-emerald-800 mb-2">
                    <p className="font-semibold">Simulated Email OTP Code:</p>
                    <p className="font-mono text-base font-bold text-emerald-900">{otpHint}</p>
                  </div>
                )}

                <div>
                  <label className="block text-[11px] font-semibold text-[#1E2A36] mb-1">OTP Code</label>
                  <input
                    type="text"
                    required
                    value={otpCode}
                    onChange={e => setOtpCode(e.target.value)}
                    placeholder="Enter 6-digit code"
                    className="w-full px-3 py-2 text-xs font-mono border border-[#D9DEE5] rounded-lg focus:outline-none focus:border-[#0057B8]"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-[#1E2A36] mb-1">New Password</label>
                  <input
                    type="password"
                    required
                    value={newPassword}
                    onChange={e => setNewPassword(e.target.value)}
                    placeholder="Minimum 6 characters"
                    className="w-full px-3 py-2 text-xs border border-[#D9DEE5] rounded-lg focus:outline-none focus:border-[#0057B8]"
                  />
                </div>

                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setStep('REQUEST')}
                    className="px-4 py-2 text-xs font-medium text-[#6E7A87] hover:bg-[#F3F5F7] rounded-lg"
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 text-xs font-semibold text-white bg-[#0057B8] hover:bg-[#004bb0] rounded-lg"
                  >
                    Reset Password
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
