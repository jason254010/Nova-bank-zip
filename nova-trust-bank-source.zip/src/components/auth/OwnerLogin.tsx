import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { apiRequest } from '../../services/api';
import { Building2, Mail, Lock, ArrowRight, ShieldCheck, HelpCircle } from 'lucide-react';

interface OwnerLoginProps {
  onSwitchToCustomer: () => void;
}

export const OwnerLogin: React.FC<OwnerLoginProps> = ({ onSwitchToCustomer }) => {
  const { login, showToast } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showForgotModal, setShowForgotModal] = useState(false);
  const [resetEmail, setResetEmail] = useState('');
  const [otpHint, setOtpHint] = useState<string | null>(null);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      showToast('Please fill in your login credentials.', 'error');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await apiRequest('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({
          loginIdentifier: email,
          password,
          loginType: 'OWNER'
        })
      });

      login(res);
    } catch (err: any) {
      showToast(err.message || 'Owner authentication failed.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!resetEmail) return;

    try {
      const res = await apiRequest('/api/auth/forgot-password', {
        method: 'POST',
        body: JSON.stringify({ email: resetEmail })
      });
      showToast(res.message, 'success');
      if (res.otpCodeHint) {
        setOtpHint(res.otpCodeHint);
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to process request', 'error');
    }
  };

  return (
    <div className="min-h-screen bg-[#F3F5F7] flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
        <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-[#0057B8] text-white shadow-lg mb-3">
          <Building2 className="w-8 h-8" />
        </div>
        <h2 className="text-2xl font-bold text-[#0F3557] font-sans">
          Bank Owner Portal
        </h2>
        <div className="mt-1 flex items-center justify-center gap-1.5">
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-[#0F3557] text-[#A9D8F7]">
            https://novatrustbank.web.app/admin
          </span>
        </div>
        <p className="mt-1.5 text-xs text-[#6E7A87]">
          Nova Trust Bank Operational & Administrative Console
        </p>
      </div>

      <div className="mt-6 sm:mx-auto sm:w-full sm:max-w-md px-4">
        <div className="bg-white py-8 px-6 sm:px-10 shadow-xl rounded-2xl border border-[#D9DEE5]">
          
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-[#1E2A36] uppercase tracking-wider mb-1.5">
                Owner Email Address
              </label>
              <div className="relative rounded-lg shadow-xs">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#6E7A87]">
                  <Mail className="h-4 w-4" />
                </div>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="owner@novatrustbank.com"
                  className="block w-full pl-10 pr-3 py-2.5 text-xs rounded-lg border border-[#D9DEE5] focus:ring-2 focus:ring-[#0057B8] focus:border-[#0057B8] text-[#1E2A36]"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-semibold text-[#1E2A36] uppercase tracking-wider">
                  Password
                </label>
                <button
                  type="button"
                  onClick={() => setShowForgotModal(true)}
                  className="text-xs text-[#0057B8] hover:underline font-medium"
                >
                  Forgot Password?
                </button>
              </div>
              <div className="relative rounded-lg shadow-xs">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#6E7A87]">
                  <Lock className="h-4 w-4" />
                </div>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="block w-full pl-10 pr-3 py-2.5 text-xs rounded-lg border border-[#D9DEE5] focus:ring-2 focus:ring-[#0057B8] focus:border-[#0057B8] text-[#1E2A36]"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full flex justify-center items-center gap-2 py-3 px-4 rounded-xl text-xs font-semibold text-white bg-[#0057B8] hover:bg-[#004bb0] focus:outline-none focus:ring-2 focus:ring-[#0057B8] transition-colors shadow-md disabled:bg-[#D9DEE5]"
            >
              <span>{isSubmitting ? 'Authenticating...' : 'Sign In to Owner Console'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          <div className="mt-6 pt-6 border-t border-[#D9DEE5] text-center">
            <button
              onClick={onSwitchToCustomer}
              className="text-xs font-medium text-[#0057B8] hover:text-[#004bb0] flex items-center justify-center gap-1.5 mx-auto"
            >
              <span>Are you a customer? Switch to Customer Online Banking Login</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

        </div>
      </div>

      {/* Forgot Password Modal */}
      {showForgotModal && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-[#D9DEE5]">
            <h3 className="text-base font-bold text-[#0F3557] mb-2">Password Reset Request</h3>
            <p className="text-xs text-[#6E7A87] mb-4">
              Enter your registered owner email address to generate an OTP verification code.
            </p>

            <form onSubmit={handleForgotPassword} className="space-y-4">
              <input
                type="email"
                required
                value={resetEmail}
                onChange={e => setResetEmail(e.target.value)}
                placeholder="Owner Email Address"
                className="w-full px-3 py-2 text-xs border border-[#D9DEE5] rounded-lg focus:outline-none focus:border-[#0057B8]"
              />

              {otpHint && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-xs text-emerald-800">
                  <p className="font-semibold">Simulated Email OTP Code:</p>
                  <p className="font-mono text-base font-bold text-emerald-900">{otpHint}</p>
                </div>
              )}

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowForgotModal(false)}
                  className="px-4 py-2 text-xs font-medium text-[#6E7A87] hover:bg-[#F3F5F7] rounded-lg"
                >
                  Close
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold text-white bg-[#0057B8] hover:bg-[#004bb0] rounded-lg"
                >
                  Request Reset OTP
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
