import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { apiRequest } from '../../services/api';
import { Building2, ShieldCheck, KeyRound, Mail, ArrowRight, Lock } from 'lucide-react';

export const OwnerSetup: React.FC = () => {
  const { login, showToast } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!email || !password || !confirmPassword) {
      showToast('Please complete all required fields.', 'error');
      return;
    }

    if (password !== confirmPassword) {
      showToast('Passwords do not match.', 'error');
      return;
    }

    if (password.length < 6) {
      showToast('Password must be at least 6 characters long.', 'error');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await apiRequest('/api/auth/owner-setup', {
        method: 'POST',
        body: JSON.stringify({ email, password, confirmPassword })
      });

      showToast('Owner account initialized successfully!', 'success');
      login({
        user: res.user,
        token: res.token
      });
    } catch (err: any) {
      showToast(err.message || 'Owner initialization failed.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F3F5F7] flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-[#480px] text-center">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-[#0057B8] text-white shadow-lg mb-4">
          <Building2 className="w-9 h-9" />
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-[#0F3557] font-sans">
          Nova Trust Bank Setup
        </h2>
        <p className="mt-2 text-sm text-[#6E7A87]">
          Initial System Setup: Create the Bank Owner & Administrator Account
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md px-4">
        <div className="bg-white py-8 px-6 sm:px-10 shadow-xl rounded-2xl border border-[#D9DEE5]">
          
          <div className="mb-6 p-3 bg-[#A9D8F7]/20 border border-[#A9D8F7] rounded-xl flex items-start gap-3">
            <ShieldCheck className="w-5 h-5 text-[#0057B8] flex-shrink-0 mt-0.5" />
            <p className="text-xs text-[#0F3557] leading-relaxed">
              This setup form is only shown once on first launch. Once created, the Owner account will gain master control over bank operations, customer creation, and management.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-xs font-semibold text-[#1E2A36] uppercase tracking-wider mb-1.5">
                Owner Email Address
              </label>
              <div className="relative rounded-lg shadow-xs">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#6E7A87]">
                  <Mail className="h-4 w-4" />
                </div>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="admin@novatrustbank.com"
                  className="block w-full pl-10 pr-3 py-2.5 text-xs rounded-lg border border-[#D9DEE5] focus:ring-2 focus:ring-[#0057B8] focus:border-[#0057B8] text-[#1E2A36]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#1E2A36] uppercase tracking-wider mb-1.5">
                Owner Password
              </label>
              <div className="relative rounded-lg shadow-xs">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#6E7A87]">
                  <KeyRound className="h-4 w-4" />
                </div>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="block w-full pl-10 pr-3 py-2.5 text-xs rounded-lg border border-[#D9DEE5] focus:ring-2 focus:ring-[#0057B8] focus:border-[#0057B8] text-[#1E2A36]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#1E2A36] uppercase tracking-wider mb-1.5">
                Confirm Owner Password
              </label>
              <div className="relative rounded-lg shadow-xs">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#6E7A87]">
                  <Lock className="h-4 w-4" />
                </div>
                <input
                  type="password"
                  required
                  value={confirmPassword}
                  onChange={e => setConfirmPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="block w-full pl-10 pr-3 py-2.5 text-xs rounded-lg border border-[#D9DEE5] focus:ring-2 focus:ring-[#0057B8] focus:border-[#0057B8] text-[#1E2A36]"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full flex justify-center items-center gap-2 py-3 px-4 border border-transparent rounded-xl text-xs font-semibold text-white bg-[#0057B8] hover:bg-[#004bb0] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#0057B8] transition-colors shadow-md disabled:bg-[#D9DEE5]"
            >
              <span>{isSubmitting ? 'Creating Owner Account...' : 'Complete Owner Setup & Initialize Platform'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

        </div>
      </div>
    </div>
  );
};
