import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { Building2, LogOut, Bell, Shield, User as UserIcon, MessageSquare } from 'lucide-react';

interface HeaderProps {
  activeTab?: string;
  setActiveTab?: (tab: string) => void;
  onOpenSupport?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ activeTab, setActiveTab, onOpenSupport }) => {
  const { user, account, logout, unreadNotifications } = useAuth();

  return (
    <header className="bg-[#0F3557] text-white shadow-md border-b border-[#0F3557]/30 sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Brand Logo & Title */}
          <div className="flex items-center space-x-3">
            <div className="bg-[#0057B8] p-2 rounded-lg flex items-center justify-center text-white shadow-sm">
              <Building2 className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-bold text-lg tracking-tight font-sans text-white">
                  NOVA TRUST BANK
                </span>
                <span className="bg-[#A9D8F7] text-[#0F3557] text-[10px] font-semibold px-2 py-0.5 rounded-full uppercase tracking-wider font-mono">
                  {user ? (user.role === 'OWNER' ? 'Bank Admin' : 'Online Banking') : 'Secure Portal'}
                </span>
              </div>
              <p className="text-xs text-[#A9D8F7]/80 hidden sm:block">Digital Banking & Asset Management</p>
            </div>
          </div>

          {/* User Status / Navigation Actions */}
          {user ? (
            <div className="flex items-center space-x-3 sm:space-x-4">
              
              {/* Customer Quick Notifications Trigger */}
              {user.role === 'CUSTOMER' && setActiveTab && (
                <button
                  onClick={() => setActiveTab('notifications')}
                  className="relative p-2 rounded-lg text-[#A9D8F7] hover:bg-white/10 transition-colors"
                  title="Notifications"
                >
                  <Bell className="w-5 h-5" />
                  {unreadNotifications > 0 && (
                    <span className="absolute top-1 right-1 bg-red-500 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                      {unreadNotifications}
                    </span>
                  )}
                </button>
              )}

              {/* Support Quick Trigger */}
              {onOpenSupport && (
                <button
                  onClick={onOpenSupport}
                  className="p-2 rounded-lg text-[#A9D8F7] hover:bg-white/10 transition-colors flex items-center gap-1.5 text-xs font-medium"
                  title="Customer Support"
                >
                  <MessageSquare className="w-5 h-5 text-[#A9D8F7]" />
                  <span className="hidden md:inline">Support</span>
                </button>
              )}

              {/* Account Quick Info */}
              <div className="hidden lg:flex flex-col text-right pr-2 border-r border-white/10">
                <span className="text-xs font-medium text-white">{user.fullName}</span>
                <span className="text-[11px] text-[#A9D8F7] font-mono">
                  {user.role === 'CUSTOMER' && account ? `Acc: ${account.accountNumber}` : user.email}
                </span>
              </div>

              {/* Logout Button */}
              <button
                onClick={logout}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-[#0057B8] hover:bg-[#004bb0] text-white rounded-md text-xs font-medium transition-colors shadow-sm"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Logout</span>
              </button>
            </div>
          ) : (
            <div className="flex items-center space-x-2 text-xs text-[#A9D8F7]">
              <Shield className="w-4 h-4 text-[#A9D8F7]" />
              <span className="font-mono">256-Bit SSL Encrypted</span>
            </div>
          )}

        </div>
      </div>
    </header>
  );
};
