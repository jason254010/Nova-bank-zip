import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import {
  Building2,
  LogOut,
  Bell,
  Shield,
  MessageSquare,
  DollarSign,
  Send,
  History,
  CreditCard,
  FileText,
  User as UserIcon,
  Users,
  Activity,
  Settings,
  Menu,
  X,
  ChevronRight
} from 'lucide-react';

interface AppLayoutProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenSupport?: () => void;
  children: React.ReactNode;
}

interface NavItem {
  id: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: number | null;
  isSupport?: boolean;
  isLive?: boolean;
}

export const AppLayout: React.FC<AppLayoutProps> = ({
  activeTab,
  setActiveTab,
  onOpenSupport,
  children
}) => {
  const { user, account, logout, unreadNotifications } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Get user initials for avatar
  const getInitials = (name?: string) => {
    if (!name) return 'NT';
    const parts = name.trim().split(' ');
    if (parts.length >= 2) {
      return `${parts[0][0]}${parts[parts.length - 1][0]}`.toUpperCase();
    }
    return name.substring(0, 2).toUpperCase();
  };

  // Nav Items for Customer
  const customerNavItems: NavItem[] = [
    { id: 'summary', label: 'Dashboard', icon: DollarSign },
    { id: 'transfer', label: 'Transfers', icon: Send },
    { id: 'history', label: 'Transactions', icon: History },
    { id: 'cards', label: 'Cards', icon: CreditCard },
    { id: 'statements', label: 'Statements', icon: FileText },
    { id: 'notifications', label: 'Notifications', icon: Bell, badge: unreadNotifications > 0 ? unreadNotifications : null },
    { id: 'profile', label: 'Security & Profile', icon: Shield },
    { id: 'support', label: 'Support', icon: MessageSquare, isSupport: true, isLive: true }
  ];

  // Nav Items for Owner
  const ownerNavItems: NavItem[] = [
    { id: 'home', label: 'Dashboard', icon: DollarSign },
    { id: 'customers', label: 'Customer Management', icon: Users },
    { id: 'transactions', label: 'Transaction Audit', icon: History },
    { id: 'support', label: 'Support Desk', icon: MessageSquare, isLive: true },
    { id: 'audit', label: 'Audit Logs', icon: Activity },
    { id: 'settings', label: 'Bank Settings', icon: Settings }
  ];

  const navItems = user?.role === 'OWNER' ? ownerNavItems : customerNavItems;

  const getPageTitle = () => {
    if (user?.role === 'OWNER') {
      switch (activeTab) {
        case 'home': return 'Bank Operational Console';
        case 'customers': return 'Customer Account Management';
        case 'transactions': return 'Global Transaction Audit Ledger';
        case 'support': return 'Live Customer Support Desk';
        case 'audit': return 'Security & Operations Audit';
        case 'settings': return 'Core Banking Settings';
        default: return 'Bank Admin Dashboard';
      }
    } else {
      switch (activeTab) {
        case 'summary': return 'Customer Dashboard';
        case 'transfer': return 'Internal Money Transfer';
        case 'history': return 'Transaction History';
        case 'cards': return 'Debit Card Management';
        case 'statements': return 'Monthly Account Statements';
        case 'notifications': return 'Account Alerts & Notifications';
        case 'profile': return 'Profile & Security Settings';
        default: return 'Online Banking Portal';
      }
    }
  };

  return (
    <div className="min-h-screen bg-[#F3F5F7] flex flex-col md:flex-row text-[#1E2A36]">
      
      {/* Sidebar Navigation for Desktop */}
      <aside className="hidden md:flex flex-col w-60 lg:w-64 bg-[#0F3557] text-white min-h-screen flex-shrink-0 shadow-lg sticky top-0 h-screen z-30">
        
        {/* Brand Logo & Header */}
        <div className="p-6 flex items-center gap-3 border-b border-white/10">
          <div className="w-9 h-9 bg-[#0057B8] rounded-md flex items-center justify-center text-white font-extrabold text-lg shadow-sm">
            N
          </div>
          <div>
            <div className="text-base font-bold tracking-tight text-white leading-tight font-sans">
              NOVA TRUST
            </div>
            <div className="text-[10px] text-[#A9D8F7] font-semibold tracking-wider uppercase">
              {user?.role === 'OWNER' ? 'ADMIN CONSOLE' : 'ONLINE BANKING'}
            </div>
          </div>
        </div>

        {/* Navigation List */}
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          {navItems.map(item => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => {
                  if (item.isSupport && onOpenSupport) {
                    onOpenSupport();
                  } else {
                    setActiveTab(item.id);
                  }
                }}
                className={`w-full flex items-center justify-between px-3.5 py-3 rounded-lg text-xs font-medium transition-all ${
                  isActive
                    ? 'bg-white/10 text-white font-semibold border-l-4 border-[#0057B8] shadow-xs'
                    : 'text-[#A9D8F7]/80 hover:bg-white/5 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-[#A9D8F7]' : 'text-[#A9D8F7]/70'}`} />
                  <span>{item.label}</span>
                </div>

                <div className="flex items-center gap-1.5">
                  {item.badge && (
                    <span className="bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.2 rounded-full">
                      {item.badge}
                    </span>
                  )}
                  {item.isLive && (
                    <span className="support-badge-live">
                      LIVE
                    </span>
                  )}
                </div>
              </button>
            );
          })}
        </nav>

        {/* Footer Session Info */}
        <div className="p-4 border-t border-white/10 text-[11px] text-[#A9D8F7]/60 space-y-1">
          <div className="flex items-center justify-between">
            <span>Status:</span>
            <span className="text-emerald-400 font-semibold flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              Encrypted
            </span>
          </div>
          <div>Last Login: Today, 09:12 AM</div>
        </div>

      </aside>

      {/* Mobile Top Navigation Bar */}
      <div className="md:hidden bg-[#0F3557] text-white p-4 flex items-center justify-between border-b border-white/10 sticky top-0 z-40">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 bg-[#0057B8] rounded-md flex items-center justify-center text-white font-bold text-sm">
            N
          </div>
          <span className="font-bold text-sm tracking-tight">NOVA TRUST BANK</span>
        </div>

        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="p-1.5 rounded-md text-[#A9D8F7] hover:bg-white/10"
        >
          {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Drawer Navigation Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#0F3557] text-white p-4 border-b border-white/10 space-y-2 z-40">
          {navItems.map(item => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  if (item.isSupport && onOpenSupport) {
                    onOpenSupport();
                  } else {
                    setActiveTab(item.id);
                  }
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-medium ${
                  isActive ? 'bg-[#0057B8] text-white font-bold' : 'text-[#A9D8F7] hover:bg-white/10'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </div>
                {item.isLive && <span className="support-badge-live">LIVE</span>}
              </button>
            );
          })}
        </div>
      )}

      {/* Main Workspace Container */}
      <div className="flex-1 flex flex-col min-w-0">
        
        {/* Top Header Bar */}
        <header className="bg-white border-b border-[#D9DEE5] h-16 sm:h-18 px-4 sm:px-8 flex items-center justify-between sticky top-0 z-20 shadow-2xs">
          
          <div>
            <h1 className="text-lg sm:text-xl font-bold text-[#0F3557] tracking-tight font-sans">
              {getPageTitle()}
            </h1>
            <p className="text-[11px] text-[#6E7A87] hidden sm:block">
              Nova Trust Bank • Official Secure Banking Environment
            </p>
          </div>

          {user && (
            <div className="flex items-center gap-3 sm:gap-4">
              
              {/* Customer Notifications Quick Action */}
              {user.role === 'CUSTOMER' && (
                <button
                  onClick={() => setActiveTab('notifications')}
                  className="relative p-2 rounded-lg text-[#6E7A87] hover:bg-[#F3F5F7] transition-colors"
                  title="Notifications"
                >
                  <Bell className="w-5 h-5 text-[#0F3557]" />
                  {unreadNotifications > 0 && (
                    <span className="absolute top-1 right-1 bg-red-500 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                      {unreadNotifications}
                    </span>
                  )}
                </button>
              )}

              {/* Support Button */}
              {onOpenSupport && (
                <button
                  onClick={onOpenSupport}
                  className="p-2 text-[#0F3557] hover:bg-[#F3F5F7] rounded-lg transition-colors flex items-center gap-1.5 text-xs font-semibold"
                  title="Live Support"
                >
                  <MessageSquare className="w-5 h-5 text-[#0057B8]" />
                  <span className="hidden sm:inline">Support</span>
                </button>
              )}

              {/* User Profile Summary */}
              <div
                onClick={() => {
                  if (user.role === 'CUSTOMER') {
                    setActiveTab('profile');
                  }
                }}
                className={`flex items-center gap-3 pl-2 sm:pl-4 border-l border-[#D9DEE5] ${
                  user.role === 'CUSTOMER' ? 'cursor-pointer group' : ''
                }`}
                title={user.role === 'CUSTOMER' ? 'View Profile' : undefined}
              >
                <div className="text-right hidden sm:block">
                  <div className="text-xs font-semibold text-[#1E2A36] leading-tight group-hover:text-[#0057B8] transition-colors">{user.fullName}</div>
                  <div className="text-[11px] text-[#6E7A87] font-mono">
                    {user.role === 'CUSTOMER' && account ? `Acc: ${account.accountNumber}` : user.email}
                  </div>
                </div>

                {user.profilePicture ? (
                  <img
                    src={user.profilePicture}
                    alt={user.fullName}
                    className="w-9 h-9 rounded-full object-cover border-2 border-[#0057B8] shadow-xs group-hover:scale-105 transition-transform"
                  />
                ) : (
                  <div className="w-9 h-9 rounded-full bg-[#0F3557] text-[#A9D8F7] font-extrabold text-xs flex items-center justify-center shadow-xs group-hover:scale-105 transition-transform">
                    {getInitials(user.fullName)}
                  </div>
                )}

                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    logout();
                  }}
                  className="p-2 text-[#6E7A87] hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors ml-1"
                  title="Logout"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>

            </div>
          )}

        </header>

        {/* Page Content Body */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto">
          {children}
        </main>

      </div>

    </div>
  );
};
