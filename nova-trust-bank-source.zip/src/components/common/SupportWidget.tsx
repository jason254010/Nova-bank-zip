import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../../context/AuthContext';
import { apiRequest } from '../../services/api';
import { SupportConversation, SupportMessage, SupportAttachment } from '../../types';
import {
  MessageSquare,
  X,
  Send,
  Paperclip,
  FileText,
  Image as ImageIcon,
  Download,
  CheckCircle,
  Clock,
  UserCircle2,
  Headphones
} from 'lucide-react';

interface SupportWidgetProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SupportWidget: React.FC<SupportWidgetProps> = ({ isOpen, onClose }) => {
  const { user, showToast } = useAuth();
  const [conversation, setConversation] = useState<SupportConversation | null>(null);
  const [messages, setMessages] = useState<SupportMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [attachments, setAttachments] = useState<SupportAttachment[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const loadConversationAndMessages = async () => {
    if (!isOpen) return;
    setIsLoading(true);
    try {
      // Get conversation for user or guest
      const convs = await apiRequest<SupportConversation[]>('/api/support/conversations');
      if (convs && convs.length > 0) {
        const activeConv = convs[0];
        setConversation(activeConv);

        const msgs = await apiRequest<SupportMessage[]>(`/api/support/conversations/${activeConv.id}/messages`);
        setMessages(msgs);
      }
    } catch (e) {
      console.error('Failed to load support conversation:', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadConversationAndMessages();
  }, [isOpen]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Poll for new messages every 4 seconds when widget is open
  useEffect(() => {
    if (!isOpen || !conversation) return;
    const interval = setInterval(async () => {
      try {
        const msgs = await apiRequest<SupportMessage[]>(`/api/support/conversations/${conversation.id}/messages`);
        setMessages(msgs);
      } catch (e) {
        // Ignore background errors
      }
    }, 4000);
    return () => clearInterval(interval);
  }, [isOpen, conversation]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach((file: File) => {
      if (file.size > 5 * 1024 * 1024) {
        showToast(`File ${file.name} exceeds 5MB limit`, 'error');
        return;
      }

      const reader = new FileReader();
      reader.onload = () => {
        const dataUrl = reader.result as string;
        setAttachments(prev => [
          ...prev,
          {
            id: 'att_' + Math.random().toString(36).substring(2),
            name: file.name,
            type: file.type,
            url: dataUrl,
            size: file.size
          }
        ]);
      };
      reader.readAsDataURL(file);
    });
  };

  const removeAttachment = (id: string) => {
    setAttachments(prev => prev.filter(a => a.id !== id));
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() && attachments.length === 0) return;
    if (!conversation) return;

    setIsSending(true);
    try {
      const msg = await apiRequest<SupportMessage>('/api/support/messages', {
        method: 'POST',
        body: JSON.stringify({
          conversationId: conversation.id,
          text: newMessage.trim(),
          attachments
        })
      });

      setMessages(prev => [...prev, msg]);
      setNewMessage('');
      setAttachments([]);
      scrollToBottom();
    } catch (err: any) {
      showToast(err.message || 'Failed to send support message', 'error');
    } finally {
      setIsSending(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 sm:inset-auto sm:bottom-4 sm:right-4 z-50 sm:w-[420px] sm:h-[600px] bg-white sm:rounded-2xl shadow-2xl border border-[#D9DEE5] flex flex-col overflow-hidden animate-fade-in">
      
      {/* Support Header */}
      <div className="bg-[#0F3557] text-white p-4 flex items-center justify-between border-b border-[#0057B8]/30">
        <div className="flex items-center gap-3">
          <div className="bg-[#0057B8] p-2 rounded-xl text-white">
            <Headphones className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-semibold text-sm">Nova Trust Support</h3>
            <div className="flex items-center gap-1.5 text-xs text-[#A9D8F7]">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span>24/7 Priority Live Support</span>
            </div>
          </div>
        </div>
        <button
          onClick={onClose}
          className="text-[#A9D8F7] hover:text-white p-1 rounded-lg transition-colors"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Messages List */}
      <div className="flex-1 p-4 overflow-y-auto bg-[#F3F5F7] space-y-3">
        {isLoading ? (
          <div className="flex flex-col items-center justify-center h-full text-center p-6 text-[#6E7A87]">
            <Clock className="w-8 h-8 animate-spin text-[#0057B8] mb-2" />
            <p className="text-xs">Connecting to secure chat server...</p>
          </div>
        ) : messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center p-6 bg-white rounded-xl border border-[#D9DEE5] shadow-xs">
            <MessageSquare className="w-10 h-10 text-[#0057B8] mb-2" />
            <h4 className="font-semibold text-sm text-[#1E2A36]">How can we assist you today?</h4>
            <p className="text-xs text-[#6E7A87] mt-1 max-w-xs">
              Send a message or upload documents/screenshots to connect instantly with bank support.
            </p>
          </div>
        ) : (
          messages.map(msg => {
            const isMe = user ? msg.senderId === user.id : msg.senderRole === 'CUSTOMER';
            return (
              <div
                key={msg.id}
                className={`flex gap-2 ${isMe ? 'flex-row-reverse items-end' : 'flex-row items-start'}`}
              >
                {/* Sender Avatar */}
                {isMe && user?.profilePicture ? (
                  <img src={user.profilePicture} alt={msg.senderName} className="w-7 h-7 rounded-full object-cover border border-[#0057B8] flex-shrink-0 mb-1" />
                ) : (
                  <div className={`w-7 h-7 rounded-full text-[10px] font-bold flex items-center justify-center flex-shrink-0 mb-1 ${
                    isMe ? 'bg-[#0057B8] text-white' : 'bg-[#0F3557] text-[#A9D8F7]'
                  }`}>
                    {msg.senderName ? msg.senderName.substring(0, 2).toUpperCase() : 'NT'}
                  </div>
                )}

                <div className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}>
                  <div className="flex items-center gap-1.5 text-[10px] text-[#6E7A87] mb-1 px-1">
                    <span className="font-medium">{msg.senderName}</span>
                    <span>•</span>
                    <span>{new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                  </div>

                  <div
                    className={`p-3 rounded-2xl max-w-[85%] text-xs shadow-xs ${
                      isMe
                        ? 'bg-[#0057B8] text-white rounded-tr-none'
                        : 'bg-white text-[#1E2A36] border border-[#D9DEE5] rounded-tl-none'
                    }`}
                  >
                  {msg.text && <p className="whitespace-pre-wrap leading-relaxed">{msg.text}</p>}

                  {/* Attachments rendering */}
                  {msg.attachments && msg.attachments.length > 0 && (
                    <div className="mt-2 space-y-1.5 border-t border-white/20 pt-2">
                      {msg.attachments.map(att => (
                        <div
                          key={att.id}
                          className={`flex items-center justify-between gap-2 p-2 rounded-lg text-[11px] ${
                            isMe ? 'bg-white/10 text-white' : 'bg-[#F3F5F7] text-[#1E2A36]'
                          }`}
                        >
                          <div className="flex items-center gap-2 truncate">
                            {att.type.startsWith('image/') ? (
                              <ImageIcon className="w-4 h-4 flex-shrink-0" />
                            ) : (
                              <FileText className="w-4 h-4 flex-shrink-0" />
                            )}
                            <span className="truncate max-w-[140px] font-mono">{att.name}</span>
                          </div>

                          <a
                            href={att.url}
                            download={att.name}
                            className="p-1 rounded hover:bg-black/10 transition-colors"
                            title="Download Attachment"
                          >
                            <Download className="w-3.5 h-3.5" />
                          </a>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Attachment Previews Before Sending */}
      {attachments.length > 0 && (
        <div className="px-3 py-2 bg-white border-t border-[#D9DEE5] flex flex-wrap gap-2">
          {attachments.map(att => (
            <div key={att.id} className="flex items-center gap-1.5 bg-[#A9D8F7]/30 text-[#0F3557] px-2 py-1 rounded-md text-xs">
              <span className="truncate max-w-[120px] font-mono">{att.name}</span>
              <button onClick={() => removeAttachment(att.id)} className="hover:text-red-600">
                <X className="w-3 h-3" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Message Input Form */}
      <form onSubmit={handleSendMessage} className="p-3 bg-white border-t border-[#D9DEE5] flex items-center gap-2">
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileUpload}
          multiple
          accept="image/*,application/pdf"
          className="hidden"
        />
        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          className="p-2 text-[#6E7A87] hover:text-[#0057B8] hover:bg-[#F3F5F7] rounded-lg transition-colors"
          title="Attach files (Images, PDFs, Screenshots)"
        >
          <Paperclip className="w-5 h-5" />
        </button>

        <input
          type="text"
          value={newMessage}
          onChange={e => setNewMessage(e.target.value)}
          placeholder="Type your message..."
          className="flex-1 bg-[#F3F5F7] text-xs px-3 py-2.5 rounded-lg border border-[#D9DEE5] focus:outline-none focus:border-[#0057B8]"
        />

        <button
          type="submit"
          disabled={isSending || (!newMessage.trim() && attachments.length === 0)}
          className="bg-[#0057B8] hover:bg-[#004bb0] disabled:bg-[#D9DEE5] text-white p-2.5 rounded-lg transition-colors flex items-center justify-center"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
};
